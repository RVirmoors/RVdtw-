
#include<stdlib.h>  
#include<time.h>
#include<stdio.h> 
#include<fstream>
#include<iostream>
#include<math.h>        
#include "ext.h"
#include "ext_obex.h"
#include "ext_systhread.h"
#include "JF_lstm.hpp"						// required for MSP objects

/**
	lstm.cpp
 
	Wesley Jackson 2011
 
	Thanks to Judy Franklin for providing the code of her network (2004), 
		and to Felix Gers, Nicol Schraudolph & Jurgen Schmidhuber (2002) for providing pseudocode for the lstm network!
 
	=====
 
	A long short-term memory recurrent neural network (a series of hidden units within hidden units) with user-defined parameters & topology.
	Can learn time-sensitive information, such as rhythm or waveforms.
 
	ABOUT:
	• Input:
		• inlet 1: 
			> targets (float 0. - 1./list)
			> messages: 
				• setminchange float int: end training if net weight changes of int timesteps < float
				• learningrates float float float: recurrent unit, memory block, output unit momentum rates
		• inlet 2: bang to reset
		• inlet 3: inputs (float 0. - 100.); read; write
	• Output:
		• inlet 1: net square error; out 1 if done training, else 0
		• inlet 2: train/test cycle time
		• inlet 3: output (float 0. - 1.)
 
	*** April 2, 2011 *** As of now, only one of these networks can be up at once since the network variables are shared; 
	I don't know how to move the network classes & class functions inside a typedef struct to permit independent instantiations...
 
 
	OPEN QUESTIONS:
	- 
*/

typedef struct {
	void *m_proxy;
	void *m_out;
	short m_argc;
	t_atom m_argv[128];
	short m_on;
} t_member;

typedef struct {
	///t_object b_ob;
	t_object b_ob;
	long b_num;
	t_member *b_mem;
	long b_id;
	t_systhread_mutex	c_mutex;
	
} t_lstm;

FILE *fr;

void lstm_bang(t_lstm *x);
void lstm_anything(t_lstm *x, t_symbol *s, short argc, t_atom *argv);
void lstm_float(t_lstm *x,double f);
void lstm_int(t_lstm *x,long n);
void lstm_list(t_lstm *x, t_symbol *s, short argc, t_atom *argv);
void lstm_atom(t_lstm *x, t_atom *a);
short lstm_all(t_lstm *x);
void lstm_off(t_lstm *x);
void lstm_out(t_lstm *x);
void outlet_member(void *out, short argc, t_atom *argv);
void lstm_assist(t_lstm *x, void *b, long m, long a, char *s);
void lstm_inletinfo(t_lstm *x, void *b, long a, char *t);
void lstm_free(t_lstm *x);
void *lstm_new(t_symbol *s, long argc, t_atom *argv);
void lstm_clear(t_lstm *x);
void lstm_read(t_lstm *x, t_symbol *s);
void lstm_doread(t_lstm *x, t_symbol *s);
void lstm_openfile(t_lstm *x, char *filename, short path);
void lstm_dowrite(t_lstm *x, t_symbol *s);
void lstm_writefile(t_lstm *x, char *filename, short path);
void lstm_write(t_lstm *x, t_symbol *s);
void lstm_initNW(t_lstm *x);
void lstm_LSTM(t_lstm *x);
void getfilepath(short in_path, char *in_filename, char *out_filepath);

t_atom sendOut[500]; // Output gets transferred here to output from object
long int NWSize = 0;
float cycleTime = 0.0; // Time it takes the network to process the input

float err=0.0, squareError=1.0, ExamplesquareError = 0.0;
int testing = 0;			// testing or training network?
int print = 1;				// print network info in Max window

float minchange = 0.0;		// minimum amount of net weight change (stop training when under this for at least minchangecount # of consecutive timesteps)
float lastchange = 0.0;		// keep track of weight change...
int minchangethresh = 0;	// # of consecutive timesteps min weight change condition must be met
int minchangecount = 0;		// iterate up to thresh
int everyhowmany = 0;		// keep track of momentum changes
float change = 0.0;

t_symbol *ps_list;

float Inputs[500];
float Outputs[500];
float Targets[500];
int T = 0;
bool feedback = T;
bool TargetsLoaded = false; // inputs cannot load until targets have updated

static t_class	*lstm_class = NULL; // needed for C++
using namespace std;

//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

double m = 0.0;  // recurrent unit momentum rate
double m0 = 0.0;  // hidden unit (blocks) momentum rate
double m0out = 0.0;  // output unit momentum rate
double Alpha = .15;
double AlphaOut = .05;
double alpham = 0.0;
/*const*/ double StopError = .02;

int max(int num1, int num2)
{
	if(num1 > num2)
		return num1;
	else
		return num2;
}

int min(int num1, int num2)
{
	if(num1 > num2)
		return num2;
	else
		return num1;
}

LSTMnet lstm;

InputUnit::InputUnit()
{
	input = 0.0;
	
	// Input Units just serve to deliver external inputs
}

void InputUnit::ScaleInputs()
{
	for (int j=0; j<NumInputs; j++) {
		Inputs[j] = 1/(1 + pow(2.71828, -Inputs[j]));
		input = Inputs[j];
	}
}

void LSTMnet::ScaleTargets()
{
	for (int j=0; j<NumOutputs; j++) {
		Targets[j] = 1/(1 + pow(2.71828, -Targets[j]));
		targets[j] = Targets[j];
	}
}

void InputUnit::SetInput(double nextin)
{
	input = nextin;
}

double InputUnit::GetOutput()
{
	return	input;
}



////////////////////////////////////////////////////////////////////////////////////////
// OutputUnit
////////////////////////////////////////////////////////////////////////////////////////

double OutputUnit::inputs[6000/*NumTotalInputs*/];

OutputUnit::OutputUnit()
{ 
	int i;
	output = 0.0;
	delta=0.0;
	sum = 0.0;
	fprime = 0.0;
	
	//		///printf("\n");
	for(i=0;i<NumTotalInputs;++i)			// now (-1,1) - before (-1/200,1/200)
	{
		weights[i]= weights[i] = (((double)(rand() - RAND_MAX/2)/((double) RAND_MAX/2)))*.05; 
		deltaWeights[i]=0.0;
		//			///printf("%lf, ", weights[i]);
	}
	
	inputs[NumTotalInputs -1] = 1.0; // Gers=2.0; Franklin=1.0;
}


// inputs to output units are:
//    cell outputs, external inputs 

void OutputUnit::SetInputs(int T, MemBlock * blocks, InputUnit * externalInputs)
{
	int i,j,k;
	
	for(i=0; i < NumMemBlocks * NumCells; )
		for(j=0; j < NumMemBlocks; ++j)
			for(k=0; k < NumCells; ++k)
			{
				if(T != 0) {
					inputs[i] = blocks[j].cells[k].GetOutput();
				}
				else {
					inputs[i] = 0.0;
				}
				i++;
			}
	
	for(i= NumMemBlocks*NumCells; i < NumTotalInputs -1; ++i)
	{
	    if(directInputFlag == 1)
			inputs[i] = externalInputs[i-NumMemBlocks*NumCells].GetOutput();
	    else
			inputs[i] = 0.0;  
	}
}


double OutputUnit::ComputeSum()
{
	int i;
	sum = 0.0;
	for(i=0;i<NumTotalInputs;++i)
	{
		sum+=weights[i]*inputs[i];
	}
	return sum;
}

double OutputUnit::GetSum()
{
	return sum;
}

double OutputUnit::ComputeOutput()
{
	double denom;
	
	denom = (1.0 + (double) exp(-sigexp * sum));
	output = 1.0/denom;   
	return output;
}

double OutputUnit::ComputeFprime()
{
	fprime = output*(1-output);
	return fprime;
}

double OutputUnit::GetFprime()
{
	return fprime;
}


double OutputUnit::GetOutput()      
{
	return output;
}


double OutputUnit::ComputeError(double target)
{
	err = target - output;
	return err;
}

double OutputUnit::GetError()
{
	return err;
}

double OutputUnit::ComputeDelta()
{
	delta = fprime * err;
	return delta;
}

double OutputUnit::GetDelta()
{
	return delta;
}


double OutputUnit::GetWeight(int index)    
{
	return weights[index];
}



void OutputUnit::UpdateWeights()
{
	int m;
	double deltaW = 0.0;
	
	for(m=0;m<NumTotalInputs;++m)    
	{                            
		deltaW = delta * inputs[m];
		weights[m] += AlphaOut*deltaW + m0out * deltaWeights[m];  // weight update includes momentum term
		deltaWeights[m] = deltaW;
	}
}




////////////////////////////////////////////////////////////////////////////////////////
//InputGate
////////////////////////////////////////////////////////////////////////////////////////
// derivative methods for inputgate are part of memory cell class.
// also error computations for weight updates is done in memory cell method

InputGate::InputGate()  
{
	int i;
	output = 0.0;
	err =0.0;
	sum = 0.0;
	fprime = 0.0;
	
	for(i=0;i<NumTotalInputs;++i)		
	{
		weights[i]= weights[i] = (((double)(rand() - RAND_MAX/2)/((double) RAND_MAX/2)))*.05; 
		
		deltaWeights[i]=0.0;
		//			///printf("%lf, ", weights[i]);
		
	}
	
}

void InputGate::InitBias(double bias)
{
	weights[NumTotalInputs -1] = bias;
}

double InputGate::ComputeSum(double * inputs)
{
	int i;
	sum = 0.0;
	for(i=0;i<NumTotalInputs;++i)
	{
		sum+=weights[i]*inputs[i];
	}
	return sum;
}


double InputGate::ComputeOutput()
{
	double denom;
	
	denom = (1.0 + (double) exp(-sigexp * sum));
	output = 1.0/denom;   
	return output;
}

double InputGate::GetOutput()      
{
	return output;
}

double InputGate::ComputeFprime()
{
	fprime = output*(1-output);
	return fprime;
}

double InputGate::GetFprime()  // deriv computation in MemoryCell will need this passed in
{
	return fprime;
}

void InputGate::UpdateWeights(MemoryCell * cells)
{
	int i,S;
	double sum=0.0;
	
	for(i=0;i<NumTotalInputs; ++i)
	{	
		sum = 0.0;
		for(S=0; S < NumCells; ++S) {
			sum += cells[S].GetEcvj() * cells[S].GetDsinvj(i);
		}
		
		weights[i] = Alpha * sum;
	}
	
}




////////////////////////////////////////////////////////////////////////////////////////
//OutputGate
////////////////////////////////////////////////////////////////////////////////////////
// derivative methods for outputgate are part of memory cell class.
// also error computations for weight updates is done in memory cell method

OutputGate::OutputGate()
{
	int i;
	output = 0.0;
	err =0.0;
	sum = 0.0;
	fprime = 0.0;
	
	for(i=0;i<NumTotalInputs;++i)		
	{
		weights[i]= weights[i] = (((double)(rand() - RAND_MAX/2)/((double) RAND_MAX/2)))*.05; 
		deltaWeights[i]=0.0;
		//			///printf("%lf, ", weights[i]);
	}
}

void OutputGate::InitBias(double bias)
{
	weights[NumTotalInputs -1] = bias;
}


double OutputGate::ComputeSum(double * inputs)
{
	int i;
	sum = 0.0;
	for(i=0;i<NumTotalInputs;++i)
	{
		sum+=weights[i]*inputs[i];
	}
	return sum;
}

double OutputGate::ComputeOutput()   // range of output gate is [0,1]
{
	double denom;
	
	denom = (1.0 + (double) exp(-sigexp * sum));
	output = 1.0/denom;   
	return output;
}

double OutputGate::GetOutput()      
{
	return output;
}


double OutputGate::ComputeFprime()
{
	fprime = output*(1-output);
	return fprime;
}

double OutputGate::GetFprime()  // deriv computation in MemoryCell will need this passed in
{
	return fprime;
}



void OutputGate::ComputeDeltaOutj(MemoryCell * cells)
{
	int k;
	double delta=0.0;
	
	for(k=0; k < NumCells; ++k) 
		delta += cells[k].GetOutput() * cells[k].GetDelta();
	
	deltaOutj = fprime*delta;
}

void OutputGate::UpdateWeights(double * inputs)
{
	
	
	int m;
	double deltaW = 0.0;
	
	for(m=0;m<NumTotalInputs;++m)    
	{   
		deltaW = deltaOutj * inputs[m];
		weights[m] += Alpha*deltaW + m0 * deltaWeights[m];  // weight update includes momentum term
		deltaWeights[m] = deltaW;
	}
}


////////////////////////////////////////////////////////////////////////////////////////
//ForgetGate
////////////////////////////////////////////////////////////////////////////////////////
// derivative methods for forgetgate are part of memory cell class.
// also error computations for weight updates is done in memory cell method

ForgetGate::ForgetGate()  
{
	int i;
	output = 0.0;
	err =0.0;
	sum = 0.0;
	fprime = 0.0;
	
	for(i=0;i<NumTotalInputs;++i)		
	{
		weights[i]= weights[i] = (((double)(rand() - RAND_MAX/2)/((double) RAND_MAX/2)))*.05; 
		deltaWeights[i]=0.0;
		//			///printf("%lf, ", weights[i]);
		
	}
	
}


void ForgetGate::InitBias(double bias)
{
	weights[NumTotalInputs-1] = bias;
}


double ForgetGate::ComputeSum(double * inputs)
{
	int i;
	sum = 0.0;
	for(i=0;i<NumTotalInputs;++i)
	{
		sum+=weights[i]*inputs[i];
	}
	return sum;
}


double ForgetGate::ComputeOutput()
{
	double denom;
	
	denom = (1.0 + (double) exp(-sigexp * sum));
	output = 1.0/denom;   
	return output;
}

double ForgetGate::GetOutput()      
{
	return output;
}


double ForgetGate::ComputeFprime()
{
	fprime = output*(1-output);
	return fprime;
}

double ForgetGate::GetFprime()  // deriv computation in  will need this passed in
{
	return fprime;
}

void ForgetGate::UpdateWeights(MemoryCell * cells)
{
	int i,S;
	double sum=0.0;
	
	for(i=0;i<NumTotalInputs; ++i)
	{	
		sum = 0.0;
		for(S=0; S < NumCells; ++S)
			sum += cells[S].GetEcvj() * cells[S].GetDsphivj(i);
		weights[i] = Alpha * sum;
	}
	
}



////////////////////////////////////////////////////////////////////////////////////////
//MemoryCell
////////////////////////////////////////////////////////////////////////////////////////


MemoryCell::MemoryCell()
{ 
	int i;
	
	output = 0.0;
	scvj = 0.0;
	sum = 0.0;
	hprime = 0.0;
	
	
	for(i=0;i<NumTotalInputs;++i)			// now (-1,1) - before (-1/200,1/200)
	{
		weights[i]= weights[i] = (((double)(rand() - RAND_MAX/2)/((double) RAND_MAX/2)))*.05; 
		deltaWeights[i] = 0.0;  // init momentum term
		dscvj[i] = 0.0;
		dsinvj[i]=0.0;
		dsphivj[i] = 0.0;
		
		//			///printf("%lf, ", weights[i]);
		
	}
	
	
}


void MemoryCell::SetNum(int unitnum)
{
	mynum = unitnum;
}


// Memory Cell inputs are previous cell outputs for all cells in the net
//  and also the external inputs, plus bias

void MemoryCell::ResetOutput()
{
	output = 0.0;
}

void MemoryCell::ComputeSum(double * inputs)
{
	int i;
	
	sum = 0.0;
	for(i=0;i<NumTotalInputs; ++i)
		sum += weights[i] * inputs[i];
}

double MemoryCell::GetSum()
{
	return sum;
}


double MemoryCell::ComputeG_net()  // here we use function g  This is input to cell, gated by y_inj.
{
	double denom;
	
	denom = (1.0 + (double) exp(-sigexp * sum));
	gsuboutput = 1.0/denom;   
	g_net = 4.0*(gsuboutput - 0.5); // output gate times h(s_cvj)
	return g_net;
}

double MemoryCell::GetG_net()
{
	return g_net;
}

double MemoryCell::ComputeGprime()
{
	gprime = 4.0 * gsuboutput * (1- gsuboutput);
	return gprime;
}

double MemoryCell::GetGprime()
{
	return gprime;
}

// method to update cell state
void MemoryCell::ComputeScvj(int T, double y_inj, double y_phi)  // input gate and forget gate args
{
	if(T != 0)
		scvj = y_phi * scvj  + y_inj * g_net;
	else
		scvj = 0.0;
}

double MemoryCell::GetScvj()
{
	return scvj;
}
// method to compute cell activation and output, gated by y_outj
double MemoryCell::ComputeOutput(double y_outj)  // h, range is [-1,1]
{
	double denom;
	
	denom = (1.0 + (double) exp(-sigexp * scvj));
	suboutput = 1.0/denom;   
	output = y_outj * 2.0*(suboutput - 0.5); // output gate times h(s_cvj)
	return output;
}

double MemoryCell::ComputeHprime()
{
	hprime = 2.0*suboutput*(1-suboutput);
	return hprime;
}

double MemoryCell::GetHprime()
{
	return hprime;
}


double MemoryCell::GetOutput()      
{
	return output;
}

void MemoryCell::PrintOutput()      
{
	///printf("output is %lf\n", output);
}


// deriv of cell

void MemoryCell::ComputeDscvj(double y_phij, double y_inj, double * inputs)
{					
	int m;
	
	for(m=0; m < NumTotalInputs; ++m)
		dscvj[m] = dscvj[m] * y_phij + gprime*y_inj * inputs[m]; 
}

double MemoryCell::GetDscvj(int m)
{
	return dscvj[m];
}


// deriv for input gate
void MemoryCell::ComputeDsinvj(double y_phij, double fprime_inj, double * inputs)
{					
	int m;
	
	for(m=0; m < NumTotalInputs; ++m)
		dsinvj[m] = dsinvj[m] * y_phij + g_net*fprime_inj*inputs[m]; 
}

double MemoryCell::GetDsinvj(int m)
{
	return dscvj[m];
}


// deriv for forget gate
void MemoryCell::ComputeDsphivj(double y_phij, double fprime_phij, double * inputs)
{					
	int m;
	
	for(m=0; m < NumTotalInputs; ++m)
		dsphivj[m] = dsphivj[m] * y_phij + scvj*fprime_phij* inputs[m]; 
}

double MemoryCell::GetDsphivj(int m)
{
	return dsphivj[m];
}

void MemoryCell::InitDerivs()
{
	int m;
	
	for(m=0; m < NumTotalInputs; ++m)
	{
		dscvj[m] = 0.0; 
		dsinvj[m] = 0.0; 
		dsphivj[m] = 0.0; 
	}
}



// Ecvj is error, for input and forget gates, and cell
double MemoryCell::ComputeEcvj(double y_outj)
{					
	ecvj = y_outj * hprime * delta;  // delta already computer in ComputeDelta() - not called delta in LSTM lit.
	return ecvj;
}

double MemoryCell::GetEcvj()
{
	return ecvj;
}


// memory cell outputs are stored starting from index 0 in
// the output unit inputs, starting with block 0,1,...

double MemoryCell::ComputeDelta(int blockNumber, OutputUnit * outputs)
{
	int k;
	delta = 0.0;
	for(k = 0; k < NumOutputs; ++k)                // had NumInputs in these parens. Why??
		delta += outputs[k].GetWeight(blockNumber*(NumCells) + mynum)*outputs[k].GetDelta();
	return delta;
}

double MemoryCell::GetDelta()
{
	return delta;
}

double MemoryCell::GetWeight(int index)    
{
	return weights[index];
}

void MemoryCell::UpdateWeights()
{
	int j;
	double deltaW = 0.0;
	
	
	for(j=0;j<NumTotalInputs;++j)    
	{                            
		
		deltaW = Alpha * ecvj * dscvj[j]; // weight update includes momentum
		weights[j] += deltaW  + alpham * deltaWeights[j];
		deltaWeights[j] = deltaW;					 // save momentum term
	}
}

////////////////////////////////////////////////////////////////////////////
// MemBlock
////////////////////////////////////////////////////////////////////////////

double MemBlock::inputs[6000/*NumTotalInputs*/];

MemBlock::MemBlock()
{
	int i;
	
	inputs[NumTotalInputs-1] = 1.0;  // bias
	for(i = 0; i < NumCells; ++i)
		cells[i].SetNum(i);   // a Cell needs to know its own index, to obtain weights to OutputUnits
	
}

void MemBlock::Init(int i)
{
	mynum = i;
	outgate.InitBias(biasFactor + i*biasFactor);  // multiplier was .5
	ingate.InitBias(biasFactor + i*biasFactor);
	forgate.InitBias(biasFactor + i*biasFactor);
}

void MemBlock::InitDerivs()  
{
	int i;
	
	for(i = 0; i < NumCells; ++i)
		cells[i].InitDerivs();
}

void MemBlock::SetInputs(int T, MemBlock * blocks, InputUnit * externalInputs)
{
	int i,j,k;
	
	for(i=0; i < NumMemBlocks * NumCells; )
		for(j=0; j < NumMemBlocks; ++j)
			for(k=0; k < NumCells; ++k)
			{
				if(T != 0)
					inputs[i] = blocks[j].cells[k].GetOutput();
				else
					inputs[i] = 0.0;
				i++;
			}
	
	for(i= NumMemBlocks*NumCells; i < NumTotalInputs-1; ++i)
	{
		inputs[i] = externalInputs[i-NumMemBlocks*NumCells].GetOutput();
	}
	
}


////////////////////////////////////////////////////////////////////////////
// LSTMnet
//  Contains an array of MemBlocks plus
//    a set of input units and a set of output units.
//   the method Runsim() loops and does the forward pass and then
//        the backward pass.
////////////////////////////////////////////////////////////////////////////

LSTMnet::LSTMnet()
{
	int i;
	for(i=0; i < NumMemBlocks; ++i)
		blocks[i].Init(i);
	for(i=0; i < NumInputs; ++i)
		inputs[i].SetInput(0.0);
	for(i=0; i < NumOutputs; ++i)
		targets[i] = 0.0;
	
}

void LSTMnet::InitDerivs()
{
	int i;
	for(i=0; i < NumMemBlocks; ++i)
		blocks[i].InitDerivs();
}

//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

//==========================================================

int main()
{
	t_class *c; ///added
	
	c = class_new("lstm", (method)lstm_new, (method)lstm_free, (long)sizeof(t_lstm), 0L, A_GIMME /*(to take many args)*/, 0);
	
	class_addmethod(c, (method)lstm_bang,		"bang",		0);
	class_addmethod(c, (method)lstm_int,		"int",		A_LONG, 0);		
	class_addmethod(c, (method)lstm_float,		"float",	A_FLOAT, 0);	
	class_addmethod(c, (method)lstm_list,		"list",		A_GIMME, 0);
	class_addmethod(c, (method)lstm_clear,		"clear",	0);
	class_addmethod(c, (method)lstm_anything,	"anything", A_GIMME, 0);
	class_addmethod(c, (method)lstm_assist,		"assist",	A_CANT, 0);
	class_addmethod(c, (method)lstm_inletinfo,	"inletinfo",A_CANT, 0);	
	
	// takes the following messages:
	class_addmethod(c, (method)lstm_read,		"read",			A_DEFSYM, 0); // restore NW from saved text file
	class_addmethod(c, (method)lstm_write,		"write",		A_DEFSYM, 0); // save current NW state as text file
	class_register(CLASS_BOX, c); 
	lstm_class = c;
	
	ps_list = gensym("list");	
	
	return 0;
}

// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

void lstm_bang(t_lstm *x)
{
	int origin = proxy_getinlet((t_object *)x); // which inlet did the message come from?
	
	switch (origin) {
		case 1:
		{
			lstm_initNW(x);
			break;
		}
		default:
			break;
	}
}

// ########################################################################

void lstm_initNW(t_lstm *x)
{	
	lstm.InitDerivs();
	
	T = 0; // reset time
	
	for(int i=0; i < NumMemBlocks; ++i)
		lstm.blocks[i].Init(i);
	
	//===================
	
	for(int i=0; i<NumInputs; i++)
		lstm.inputs[i].SetInput(0.0);
	
	
	// LOAD INPUT GATES		
	///for(int i=0; i < NumMemBlocks * NumCells; i++)
		for(int j=0; j < NumMemBlocks; j++) {
			
			lstm.blocks[j].ingate.output = 0.0;
			lstm.blocks[j].ingate.err = 0.0;
			lstm.blocks[j].ingate.delta = 0.0;
			lstm.blocks[j].ingate.sum = 0.0;
			lstm.blocks[j].ingate.fprime = 0.0;
			lstm.blocks[j].ingate.InitBias(biasFactor + j*biasFactor);
			
			// loop over weights, deltaWeights
			for (int k=0; k<NumTotalInputs; k++) {
				lstm.blocks[j].ingate.weights[k] = (((double)(rand() - RAND_MAX/2)/((double) RAND_MAX/2)))*.05; 
				lstm.blocks[j].ingate.deltaWeights[k] = 0.0; }
			
			// LOAD FORGET GATES
			lstm.blocks[j].forgate.output = 0.0;
			lstm.blocks[j].forgate.err = 0.0;
			lstm.blocks[j].forgate.delta = 0.0;
			lstm.blocks[j].forgate.sum = 0.0;
			lstm.blocks[j].forgate.fprime = 0.0;
			lstm.blocks[j].forgate.InitBias(biasFactor + j*biasFactor);
			
			// loop over weights
			for (int k=0; k<NumTotalInputs; k++) {
				lstm.blocks[j].forgate.weights[k] = (((double)(rand() - RAND_MAX/2)/((double) RAND_MAX/2)))*.05;
				lstm.blocks[j].forgate.deltaWeights[k] = 0.0; }
			
			// LOAD OUTPUT GATES
			lstm.blocks[j].outgate.output = 0.0;
			lstm.blocks[j].outgate.err = 0.0;
			lstm.blocks[j].outgate.deltaOutj = 0.0;
			lstm.blocks[j].outgate.sum = 0.0;
			lstm.blocks[j].outgate.fprime = 0.0;
			lstm.blocks[j].outgate.InitBias(biasFactor + j*biasFactor);
			
			// loop over weights
			for (int k=0; k<NumTotalInputs; k++) {
				lstm.blocks[j].outgate.weights[k] = (((double)(rand() - RAND_MAX/2)/((double) RAND_MAX/2)))*.05; 
				lstm.blocks[j].outgate.deltaWeights[k] = 0.0;}
			
			// LOAD MEMORY CELLS
			for (int c=0; c<NumCells; c++) {
				
				lstm.blocks[j].cells[c].mynum = c;
				lstm.blocks[j].cells[c].output = 0.0;
				///lstm.blocks[j].cells[c].suboutput = atom_getfloat(argv+next); next++;
				///lstm.blocks[j].cells[c].gsuboutput = atom_getfloat(argv+next); next++;
				///lstm.blocks[j].cells[c].ecvj = atom_getfloat(argv+next); next++;
				lstm.blocks[j].cells[c].delta = 0.0;
				lstm.blocks[j].cells[c].sum = 0.0;
				///lstm.blocks[j].cells[c].g_net = atom_getfloat(argv+next); next++;
				lstm.blocks[j].cells[c].scvj = 0.0;
				lstm.blocks[j].cells[c].hprime = 0.0;
				///lstm.blocks[j].cells[c].gprime = atom_getfloat(argv+next); next++;
				
				// loop over weights
				for (int k=0; k<NumTotalInputs; k++) {
					lstm.blocks[j].cells[c].weights[k] = (((double)(rand() - RAND_MAX/2)/((double) RAND_MAX/2)))*.05; 
					lstm.blocks[j].cells[c].deltaWeights[k] = 0.0;
					lstm.blocks[j].cells[c].dscvj[k] = 0.0;
					lstm.blocks[j].cells[c].dsinvj[k] = 0.0;
					lstm.blocks[j].cells[c].dsphivj[k] = 0.0; }
				
			} // end loop over cells in this block
	
			// LOAD MEMORY BLOCKS
			lstm.blocks[j].mynum = j;
			
			for (int k=0; k<NumTotalInputs; k++)
				lstm.blocks[j].inputs[k] = 1.0; // bias
			
		} // end loop over blocks (j)
	
	// LOAD OUTPUT UNITS
	
	for (int o=0; o<NumOutputs; o++) {
		
		lstm.outputs[o].output = 0.0;
		lstm.outputs[o].err = 0.0;
		lstm.outputs[o].delta = 0.0;
		lstm.outputs[o].sum = 0.0;
		lstm.outputs[o].fprime = 0.0;
		
		for (int k=0; k<NumTotalInputs; k++) {
			lstm.outputs[o].weights[k] = (((double)(rand() - RAND_MAX/2)/((double) RAND_MAX/2)))*.05;
			lstm.outputs[o].deltaWeights[k] = 0.0;
			lstm.outputs[o].inputs[k] = 1.0; } //Gers=2.0; Franklin=1.0 
		}
		
		// LOAD LSTMNET
		
		biasFactor = -.1;
		sigexp = 1.0;
		InputScalar = 1.0;
		directInputFlag = 1;
		
		///object_post((t_object *)x, "...Network initialized!");
	
	TargetsLoaded = false;
		
}

// ########################################################################

// for reading & writing of network state...

void lstm_read(t_lstm *x, t_symbol *s)
{
	defer((t_object *)x, (method)lstm_doread, s, 0, NULL);
}

void lstm_doread(t_lstm *x, t_symbol *s)
{
	long filetype = 'TEXT', outtype;
	char filename[512];
	short path;
	
	if (s == gensym("")) {      // if no argument supplied, ask for file
		if (open_dialog(filename, &path, &outtype, &filetype, 1))       // non-zero: user cancelled
			return;
	} else {
		strcpy(filename, s->s_name);    // must copy symbol before calling locatefile_extended
		if (locatefile_extended(filename, &path, &outtype, &filetype, 1)) { // non-zero: not found
			object_error((t_object *)x, "Dammit! %s not found", s->s_name);
			return;
		}
	}
	// we have a file
	lstm_openfile(x, filename, path);
}

void lstm_openfile(t_lstm *x, char *filename, short path)
{
	t_filehandle fh;
	char *buffer;
	char cpath[1024]; // store intended filepath here
	long size;
	
	if (path_opensysfile(filename, path, &fh, READ_PERM)) {
		object_error((t_object *)x, "Dammit! Error opening %s", filename);
		return;
	}
	
	// allocate memory block that is the size of the file
	sysfile_geteof(fh, &size);
	buffer = sysmem_newptr(size);
	
	// read in the file
	sysfile_read(fh, &size, buffer);
	
	// create the file
	path_createsysfile(filename, path, 'TEXT', &fh);
	getfilepath(path, filename, cpath);
	object_post((t_object *)x, "Restoring from %s", cpath);
	
	fr = fopen (cpath, "rt"); 
		int NumInputsFile;
		int NumOutputsFile;
		int NumMemBlocksFile;
		int NumCellsFile;
		double mFile;
		double m0File;
		double m0outFile;
		double AlphaFile;
		double alphamFile;
		double AlphaOutFile;
		double StopErrorFile;
	
	while(1) /// allow break out to close file
	{
	
		fscanf(fr, "%i\n", &NumInputsFile); object_post((t_object *)x, "%i", NumInputsFile);
		fscanf(fr, "%i\n", &NumOutputsFile);object_post((t_object *)x, "%i", NumOutputsFile);
		fscanf(fr, "%i\n", &NumMemBlocksFile);object_post((t_object *)x, "%i", NumMemBlocksFile);
		fscanf(fr, "%i\n", &NumCellsFile);object_post((t_object *)x, "%i", NumCellsFile);
		fscanf(fr, "%lf\n", (double *)&mFile);object_post((t_object *)x, "%lf", mFile);
		fscanf(fr, "%lf\n", (double *)&m0File);object_post((t_object *)x, "%lf", m0File);
		fscanf(fr, "%lf\n", (double *)&m0outFile);object_post((t_object *)x, "%lf", m0outFile);
		fscanf(fr, "%lf\n", (double *)&AlphaFile);object_post((t_object *)x, "%lf", AlphaFile);
		fscanf(fr, "%lf\n", (double *)&alphamFile);object_post((t_object *)x, "%lf", alphamFile);
		fscanf(fr, "%lf\n", (double *)&AlphaOutFile);object_post((t_object *)x, "%lf", AlphaOutFile);
		fscanf(fr, "%lf\n", (double *)&StopErrorFile);object_post((t_object *)x, "%lf", StopErrorFile);
		
		// Only read this file if the object arguments match!
		
		if (NumInputs != NumInputsFile){
			object_error((t_object *)x, "Uhh, the number of inputs in this file is %i, but that of this object is %i", NumInputsFile, NumInputs);
			break; }
		else {
			if (NumOutputs != NumOutputsFile) {
				object_error((t_object *)x, "Uhh, the number of outputs in this file is %i, but that of this object is %i", NumOutputsFile, NumOutputs);
				break; }
			else {
				if (NumMemBlocks != NumMemBlocksFile) {
					object_error((t_object *)x, "Uhh, the number of memory blocks in this file is %i, but that of this object is %i", NumMemBlocksFile, NumMemBlocks);
					break; }
				else {
					if (NumCells != NumCellsFile) {
						object_error((t_object *)x, "Uhh, the number of number of memory cells in this file is %i, but that of this object is %i", NumCellsFile, NumCells);
						break; }
					else {
						if (m != mFile) {
							object_error((t_object *)x, "Uhh, m in this file is %f, but that of this object is %f", mFile, m);
							break; }
						else {
							if (m0 != m0File) {
								object_error((t_object *)x, "Uhh, m0 in this file is %f, but that of this object is %f", m0File, m0);
								break; }
							else {
								if (m0out != m0outFile) {
									object_error((t_object *)x, "Uhh, m0out in this file is %f, but that of this object is %f", m0outFile, m0out);
									break; }
								else {
									if (Alpha != AlphaFile) {
										object_error((t_object *)x, "Uhh, Alpha in this file is %f, but that of this object is %f", AlphaFile, Alpha);
										break; }
									else {
										if (alpham != alphamFile) {
											object_error((t_object *)x, "Uhh, alpham in this file is %f, but that of this object is %f", alphamFile, alpham);
											break; }
										else {
											if (AlphaOut != AlphaOutFile) {
												object_error((t_object *)x, "Uhh, AlphaOut in this file is %f, but that of this object is %f", AlphaOutFile, AlphaOut);
												break; }
											else {
												if (StopError != StopErrorFile) {
													object_error((t_object *)x, "Uhh, StopError in this file is %f, but that of this object is %f", StopErrorFile, StopError);
													break; }
												else {
													
		// If the network topologies match, load from file!		
		object_post((t_object *)x, "Network topology matches that of file! Restoring...");	
		
		for(int j=0; j < NumMemBlocks; j++) {
			
			fscanf(fr, "%lf\n", (double *)&lstm.blocks[j].ingate.output);
			fscanf(fr, "%lf\n", (double *)&lstm.blocks[j].ingate.err);
			fscanf(fr, "%lf\n", (double *)&lstm.blocks[j].ingate.delta);
			fscanf(fr, "%lf\n", (double *)&lstm.blocks[j].ingate.sum);
			fscanf(fr, "%lf\n", (double *)&lstm.blocks[j].ingate.fprime);
			
			for (int k=0; k<NumTotalInputs; k++) {
				fscanf(fr, "%lf\n", (double *)&lstm.blocks[j].ingate.weights[k]);
				fscanf(fr, "%lf\n", (double *)&lstm.blocks[j].ingate.deltaWeights[k]); }
			
			fscanf(fr, "%lf\n", (double *)&lstm.blocks[j].forgate.output);
			fscanf(fr, "%lf\n", (double *)&lstm.blocks[j].forgate.err);
			fscanf(fr, "%lf\n", (double *)&lstm.blocks[j].forgate.delta);
			fscanf(fr, "%lf\n", (double *)&lstm.blocks[j].forgate.sum);
			fscanf(fr, "%lf\n", (double *)&lstm.blocks[j].forgate.fprime);
			
			for (int k=0; k<NumTotalInputs; k++) {
				fscanf(fr, "%lf\n", (double *)&lstm.blocks[j].forgate.weights[k]);
				fscanf(fr, "%lf\n", (double *)&lstm.blocks[j].forgate.deltaWeights[k]); }
			
			fscanf(fr, "%lf\n", (double *)&lstm.blocks[j].outgate.output);
			fscanf(fr, "%lf\n", (double *)&lstm.blocks[j].outgate.err);
			fscanf(fr, "%lf\n", (double *)&lstm.blocks[j].outgate.deltaOutj);
			fscanf(fr, "%lf\n", (double *)&lstm.blocks[j].outgate.sum);
			fscanf(fr, "%lf\n", (double *)&lstm.blocks[j].outgate.fprime);
			
			for (int k=0; k<NumTotalInputs; k++) {
				fscanf(fr, "%lf\n", (double *)&lstm.blocks[j].outgate.weights[k]);
				fscanf(fr, "%lf\n", (double *)&lstm.blocks[j].outgate.deltaWeights[k]);  }
			
			for (int c=0; c<NumCells; c++) {
				fscanf(fr, "%i\n", &lstm.blocks[j].cells[c].mynum); 
				fscanf(fr, "%lf\n", (double *)&lstm.blocks[j].cells[c].output);
				fscanf(fr, "%lf\n", (double *)&lstm.blocks[j].cells[c].suboutput);
				fscanf(fr, "%lf\n", (double *)&lstm.blocks[j].cells[c].gsuboutput);
				fscanf(fr, "%lf\n", (double *)&lstm.blocks[j].cells[c].ecvj);
				fscanf(fr, "%lf\n", (double *)&lstm.blocks[j].cells[c].delta);
				fscanf(fr, "%lf\n", (double *)&lstm.blocks[j].cells[c].sum);
				fscanf(fr, "%lf\n", (double *)&lstm.blocks[j].cells[c].g_net);
				fscanf(fr, "%lf\n", (double *)&lstm.blocks[j].cells[c].scvj);
				fscanf(fr, "%lf\n", (double *)&lstm.blocks[j].cells[c].hprime);
				fscanf(fr, "%lf\n", (double *)&lstm.blocks[j].cells[c].gprime);
				
				for (int k=0; k<NumTotalInputs; k++) {
					fscanf(fr, "%lf\n", (double *)&lstm.blocks[j].cells[c].weights[k]);
					fscanf(fr, "%lf\n", (double *)&lstm.blocks[j].cells[c].deltaWeights[k]);
					fscanf(fr, "%lf\n", (double *)&lstm.blocks[j].cells[c].dscvj[k]);
					fscanf(fr, "%lf\n", (double *)&lstm.blocks[j].cells[c].dsinvj[k]);
					fscanf(fr, "%lf\n", (double *)&lstm.blocks[j].cells[c].dsphivj[k]); }
			} // end over cells c
				
				fscanf(fr, "%i\n", &lstm.blocks[j].mynum);
				
				for (int k=0; k<NumTotalInputs; k++)
					fscanf(fr, "%lf\n", (double *)&lstm.blocks[j].inputs[k]);
			} // end over mem blocks j
			
			for (int o=0; o<NumOutputs; o++) {
				fscanf(fr, "%lf\n", (double *)&lstm.outputs[o].output);
				fscanf(fr, "%lf\n", (double *)&lstm.outputs[o].err);
				fscanf(fr, "%lf\n", (double *)&lstm.outputs[o].delta);
				fscanf(fr, "%lf\n", (double *)&lstm.outputs[o].sum);
				fscanf(fr, "%lf\n", (double *)&lstm.outputs[o].fprime);
				
				for (int k=0; k<NumTotalInputs; k++) {
					fscanf(fr, "%lf\n", (double *)&lstm.outputs[o].weights[k]);
					fscanf(fr, "%lf\n", (double *)&lstm.outputs[o].deltaWeights[k]); 
					fscanf(fr, "%lf\n", (double *)&lstm.outputs[o].inputs[k]); }
			} // end over outputs o
			
			fscanf(fr, "%lf\n", (double *)&biasFactor);
			fscanf(fr, "%lf\n", (double *)&sigexp);
			fscanf(fr, "%lf\n", (double *)&InputScalar);
			fscanf(fr, "%i\n", &directInputFlag);
		}
											}
											
		object_post((t_object *)x, "Network restored!");
											
		TargetsLoaded = false;
											
		}}}}}}}}}
		
		break;
		
	}			   
	sysfile_close(fh);
	fclose(fr); 
	
	sysfile_close(fh);
	
	// do something with data in buffer here
	sysmem_freeptr(buffer);     // must free allocated memory
}	

void lstm_write(t_lstm *x, t_symbol *s)
{
	defer(x, (method)lstm_dowrite, s, 0, NULL);
}

void lstm_dowrite(t_lstm *x, t_symbol *s)
{
	long filetype = 'TEXT', outtype;
	char filename[512];
	short path;
	
	if (s == gensym("")) {      // if no argument supplied, ask for file
		if (saveasdialog_extended(filename, &path, &outtype, &filetype, 1))     // non-zero: user cancelled
			return;
	} else {
		strcpy(filename, s->s_name);
		path = path_getdefault();
	}
	lstm_writefile(x, filename, path);
}

void getfilepath(short in_path, char *in_filename, char *out_filepath)
{
	///t_lstm *x;
	char path[4096];
	
	path_topathname(in_path, in_filename, path);
	
#ifdef MAC_VERSION
	char *temppath;
	temppath = strchr(path, ':');
	*temppath = '\0';
	temppath += 1;
	
	// at this point temppath points to the path after the volume, and out_filepath points to the volume
	sprintf(out_filepath, "/Volumes/%s%s", path, temppath);
	///object_post((t_object *)x, "/Volumes/%s%s", path, temppath);
#else // WIN_VERSION
	strcpy(out_filepath, path);
#endif
}

void lstm_writefile(t_lstm *x, char *filename, short path)
{
	t_filehandle fh; 
	char cpath[1024]; // store intended filepath here
	
	// create the file
	path_createsysfile(filename, path, 'TEXT', &fh);
	getfilepath(path, filename, cpath);
	object_post((t_object *)x, "Writing to %s", cpath);
	
	// open the file & write data
	ofstream out;
	out.open(cpath, fstream::out | fstream::app);
	
	if (out.is_open()) {
		
		out << NumInputs << endl;
		out << NumOutputs << endl;
		out << NumMemBlocks << endl;
		out << NumCells << endl;
		out << m << endl;
		out << m0 << endl;
		out << m0out << endl;
		out << Alpha << endl;
		out << alpham << endl;
		out << AlphaOut << endl;
		out << StopError << endl;
		
		for(int j=0; j < NumMemBlocks; j++) {
			
			out << lstm.blocks[j].ingate.output << endl;
			out << lstm.blocks[j].ingate.err << endl;
			out << lstm.blocks[j].ingate.delta << endl;
			out << lstm.blocks[j].ingate.sum << endl;
			out << lstm.blocks[j].ingate.fprime << endl;
			
			for (int k=0; k<NumTotalInputs; k++) {
				out << lstm.blocks[j].ingate.weights[k] << endl;
				out << lstm.blocks[j].ingate.deltaWeights[k] << endl; }
			
			out << lstm.blocks[j].forgate.output << endl;
			out << lstm.blocks[j].forgate.err << endl;
			out << lstm.blocks[j].forgate.delta << endl;
			out << lstm.blocks[j].forgate.sum << endl;
			out << lstm.blocks[j].forgate.fprime << endl;
			
			for (int k=0; k<NumTotalInputs; k++) {
				out << lstm.blocks[j].forgate.weights[k] << endl;
				out << lstm.blocks[j].forgate.deltaWeights[k] << endl; }
			
			out << lstm.blocks[j].outgate.output << endl;
			out << lstm.blocks[j].outgate.err << endl;
			out << lstm.blocks[j].outgate.deltaOutj << endl;
			out << lstm.blocks[j].outgate.sum << endl;
			out << lstm.blocks[j].outgate.fprime << endl;
			
			for (int k=0; k<NumTotalInputs; k++) {
				out << lstm.blocks[j].outgate.weights[k] << endl;
				out << lstm.blocks[j].outgate.deltaWeights[k] << endl;  }
			
			for (int c=0; c<NumCells; c++) {
				out << lstm.blocks[j].cells[c].mynum << endl; 
				out << lstm.blocks[j].cells[c].output << endl;
				out << lstm.blocks[j].cells[c].suboutput << endl;
				out << lstm.blocks[j].cells[c].gsuboutput << endl;
				out << lstm.blocks[j].cells[c].ecvj << endl;
				out << lstm.blocks[j].cells[c].delta << endl;
				out << lstm.blocks[j].cells[c].sum << endl;
				out << lstm.blocks[j].cells[c].g_net << endl;
				out << lstm.blocks[j].cells[c].scvj << endl;
				out << lstm.blocks[j].cells[c].hprime << endl;
				out << lstm.blocks[j].cells[c].gprime << endl;
				
				for (int k=0; k<NumTotalInputs; k++) {
					out << lstm.blocks[j].cells[c].weights[k] << endl;
					out << lstm.blocks[j].cells[c].deltaWeights[k] << endl;
					out << lstm.blocks[j].cells[c].dscvj[k] << endl;
					out << lstm.blocks[j].cells[c].dsinvj[k] << endl;
					out << lstm.blocks[j].cells[c].dsphivj[k] << endl; }
			
			out << lstm.blocks[j].mynum << endl;
			
			for (int k=0; k<NumTotalInputs; k++)
				out << lstm.blocks[j].inputs[k] << endl;
		} // end c over cells
		} // end j over mem blocks
		
		for (int o=0; o<NumOutputs; o++) {
			out << lstm.outputs[o].output << endl;
			out << lstm.outputs[o].err << endl;
			out << lstm.outputs[o].delta << endl;
			out << lstm.outputs[o].sum << endl;
			out << lstm.outputs[o].fprime << endl;
			
			for (int k=0; k<NumTotalInputs; k++) {
				out << lstm.outputs[o].weights[k] << endl;
				out << lstm.outputs[o].deltaWeights[k] << endl; 
				out << lstm.outputs[o].inputs[k] << endl; }
		} // end o over outputs
		
			out << biasFactor << endl;
			out << sigexp << endl;
			out << InputScalar << endl;
			out << directInputFlag << endl;
		
		out.close();
		
		sysfile_close(fh);
		
		object_post((t_object *)x, "Network saved!");
	} // if not open
	else
		object_error((t_object *)x, "I couldn't open a connection with this file...");
	 
}

// ########################################################################

void lstm_clear(t_lstm *x)
{
	lstm_off(x);
}

void lstm_anything(t_lstm *x, t_symbol *s, short argc, t_atom *argv)
{
	// Custom messages
	int origin = proxy_getinlet((t_object *)x); // which inlet did the message come from?
	
	switch (origin) {
			
		case 1: 
			break;
		case 2:
			break;
		default: {
			
		// set parameters?
			if (s == gensym("setinout")) {
				if (argc != 1)
					object_error((t_object *)x, "No, silly, 'setinout' needs one argument!");
				else {
					NumInputs = atom_getfloat(argv);
					NumOutputs = atom_getfloat(argv);
					lstm_initNW(x);
				}
			}

			if (s == gensym("setnumblocks")) {
				if (argc != 1)
					object_error((t_object *)x, "No, silly, 'setnumblocks' needs one argument!");
				else {
					NumMemBlocks = atom_getfloat(argv);
					lstm_initNW(x);
				}
			}
			
			if (s == gensym("setnumcells")) {
				if (argc != 1)
					object_error((t_object *)x, "No, silly, 'setnumcells' needs one argument!");
				else {
					NumCells = atom_getfloat(argv);
					lstm_initNW(x);
				}
			}
	
		// set training time params?
		if (s  == gensym("setminchange")) {
			if (argc != 2)
				object_error((t_object *)x, "No, silly, 'setminchange' needs two arguments! (threshold and number of times to meet this threshold)");
			else {
				minchange = atom_getfloat(argv+0);
				minchangethresh = atom_getlong(argv+1);
					
				object_post((t_object *)x, "Will stop training when net weight change is less than %f for %ld consecutive timesteps.", minchange, minchangethresh);
			 }
		}
			
		// print network status in the max window?
		else if (s == gensym("print")) {
				if (argc != 1)
					object_error((t_object *)x, "No, silly, 'print' takes an argument!");
			else {
				print = atom_getfloat(argv);
			}
		}
			
		// print network info in the max window?
		else if (s == gensym("report")) {
			
			object_post((t_object *)x, "-------------------------------------------------");
			
			object_post((t_object *)x, "Network topology:\n");
			
			object_post((t_object *)x, "\tInput units: %ld", NumInputs);
			object_post((t_object *)x, "\tOutput units: %ld", NumOutputs); 
			object_post((t_object *)x, "\tMemory Blocks: %ld", NumMemBlocks);
			object_post((t_object *)x, "\tMemory Cells: %ld", NumCells); 
			object_post((t_object *)x, "\tNumber of Total Inputs: %ld", NumTotalInputs); 
			
			object_post((t_object *)x, "Momenta:\n");
			
			object_post((t_object *)x, "\tRecurrent units: %f", m);
			object_post((t_object *)x, "\tHidden units (blocks): %f", m0);
			object_post((t_object *)x, "\tOutput units: %f", m0out);
			object_post((t_object *)x, "\tAlpha: %f", Alpha);
			object_post((t_object *)x, "\talpham: %f", alpham);
			object_post((t_object *)x, "\tAlphaOut: %f", AlphaOut);
			object_post((t_object *)x, "\tStopError: %f", StopError);
			
			object_post((t_object *)x, "-------------------------------------------------");
		}
		
		// set learning rates (momentums)?
		else if (s  == gensym("learningrates")) {
			if (argc != 7)
				object_error((t_object *)x, "No, silly, I need 7 learning rates! (recurrent unit, memory blocks, output unit)");
			else {
				m = atom_getfloat(argv+0);
				m0 = atom_getfloat(argv+1);
				m0out = atom_getfloat(argv+2);
				Alpha = atom_getfloat(argv+3);
				alpham = atom_getfloat(argv+4);
				AlphaOut = atom_getfloat(argv+5);
				StopError = atom_getfloat(argv+6);
				
				object_post((t_object *)x, "Momenta:\n\t Recurrent unit: %f\n\t Memory block: %f\n\t Output unit: %f ", m, m0, m0out);
			}
		}
	}
	}
}

// ----------------------------------------------------------------

void lstm_list(t_lstm *x, t_symbol *s, short argc, t_atom *argv)
{
	///lstm_anything(x,ps_list,argc,argv);
	
	systhread_mutex_lock(x->c_mutex); // Don't let them change while they're being loaded!
	
	int origin = proxy_getinlet((t_object *)x); // which inlet did the message come from?
	
	switch (origin) {
			
		case 1: // right inlet initiates NW with specified network topology
		{/*
			// The number of general parameters must be 11!
			if (argc == 11) {
				
				char inits[10];
				
				// Load parameters
				for(int i=0; i<4 ; i++){
					if(argv[i].a_type == A_LONG) 
						inits[i] = atom_getlong(argv+i);
					else {
						object_error((t_object *)x, "Network topology parameter %ld not an integer!", i+1);
						break;
					}
				}
						
				for(int i=4; i<11; i++){
					if(argv[i].a_type == A_FLOAT) 
						inits[i] = atom_getfloat(argv+i);
					else {
						object_error((t_object *)x, "Network topology parameter %ld not a float!", i+1);
						break;
					}
					
					// initialize NW if loaded last parameter
					if (i == argc - 1)
						lstm_initNW((t_lstm *)x, inits);
				}
			}
			else {
				object_error((t_object *)x, "There must be 11 parameters, but you only give %i", argc);
			}*/
			break;
		}
				
		case 2: // middle inlet sets target output
		{
			// Network must be in training mode!
			if (testing == 1) 
				object_error((t_object *)x, "Um, targets are only for training; ignoring incoming targets...");
			else {
				
			// Only load targets if the last ones have been used
			if (TargetsLoaded)
				object_error((t_object *)x, "Cannot load new targets: waiting for inputs...");
			// The number of targets must match the number of output units!
			else 
			{
				if (argc == NumOutputs)
				{
				// Load targets
				for(int i=0; i<argc ; i++){
					if(argv[i].a_type == A_FLOAT) {
						lstm.targets[i] = atom_getfloat(argv+i);
						if (print) object_post((t_object *)x, "Target %ld = %f", i, lstm.targets[i]);
						
						if (i == NumOutputs - 1)
						{
							///lstm.ScaleTargets();
							///object_post((t_object *)x, "Scaled Target %ld = %f", i, lstm.targets[i]);
						}
					}
					else {
						object_error((t_object *)x, "Target %ld not a float!", i+1);
					}
				} // done loading targets
				
				TargetsLoaded = true;
			}
			else { 
				object_error((t_object *)x, "Number of targets (%ld) must match number of output units (%ld)!", argc, NumOutputs);
			}
			} // end if targets loaded
			} // end if training
			break;
		}
		
		/* ##############################################################
					WHEN NEW INPUTS ARRIVE, COMPUTE THEM
		 ############################################################## */
			
		default: // left inlet loads input units
		{
			// Cannot load inputs until targets have updated!
			if (!TargetsLoaded && testing == 0)
				object_error((t_object *)x, "Cannot load new inputs: waiting for targets...");
			else {
			// The number of inputs must match the number of input units!
			if (argc == NumInputs) {
				// Load input units
				for(int i=0; i<argc ; i++){
					if(argv[i].a_type == A_FLOAT) {
				
						Inputs[i] = atom_getfloat(argv+i);
						lstm.inputs[i].SetInput(atom_getfloat(argv+i));
						
						if (print) object_post((t_object *)x, "Input %ld = %f", i, lstm.inputs[i].input);
						
						// Run lstm if this is the last input
						if (i == NumInputs - 1) {
							T++; // Update time w/ new input
							///lstm.inputs[i].ScaleInputs(); // scale inputs
							///object_post((t_object *)x, "Scaled Input %ld = %f", i, lstm.inputs[i].input);
							
							lstm_LSTM(x);
						}
					}
					else {
						object_error((t_object *)x, "Input %ld not a float!", i+1);
					}
				}
			}
			else {
				object_error((t_object *)x, "Number of inputs (%ld) must match number of input units (%ld)!", argc, NumInputs);
			}
		} // end if targets loaded
		}
	}
	
	systhread_mutex_unlock(x->c_mutex);
}

// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
			

			
// #############################################################

void lstm_LSTM(t_lstm * x)
{
	// bypass if done training
	///if (!testing) {
	
	TargetsLoaded = false; // don't accept new inputs during network cycle
	
	cycleTime = clock(); // start timer
	
	int i, k;
	
	lstm.blocks[0].SetInputs(T, lstm.blocks, lstm.inputs); // self-recurrent - from MemBlocks, and from external input
	
	// Forward Pass:
	
	for(i=0; i < NumMemBlocks; ++i)
	{
		///object_post((t_object *)x, "Block %ld: ", i);
		
		lstm.blocks[i].ingate.ComputeSum(lstm.blocks[i].inputs); 		
		lstm.blocks[i].forgate.ComputeSum(lstm.blocks[i].inputs);			
		lstm.blocks[i].outgate.ComputeSum(lstm.blocks[i].inputs);	
		
		for(k=0; k < NumCells; ++k)
		{			
			lstm.blocks[i].cells[k].ComputeSum(lstm.blocks[i].inputs); 			
			lstm.blocks[i].cells[k].ComputeG_net(); 	
			
		}  // calculates g activation for cell input
		
		lstm.blocks[i].ingate.ComputeOutput();		
		lstm.blocks[i].forgate.ComputeOutput();		
		lstm.blocks[i].outgate.ComputeOutput();		
		
		for(k=0; k < NumCells; ++k)
		{
			lstm.blocks[i].cells[k].ComputeScvj(T, lstm.blocks[i].ingate.GetOutput(), lstm.blocks[i].forgate.GetOutput());
			lstm.blocks[i].cells[k].ComputeOutput(lstm.blocks[i].outgate.GetOutput());
		}  // this loop calculates cell state and cell activation h
		 
	}  // end for blocks
	
	lstm.outputs[0].SetInputs(T, lstm.blocks, lstm.inputs);  // outputs have separate set of inputs because of feedforward
	
	///object_post((t_object *)x, "-----------------------------------");
	
	for(i=0; i < NumOutputs; ++i)
	{
		lstm.outputs[i].ComputeSum();
		lstm.outputs[i].ComputeOutput();
		// *** prepare to send out of object ***
		atom_setfloat(sendOut+i, lstm.outputs[i].output); 
	}
	
	///object_post((t_object *)x, "-----------------------------------");
	
	
	
	// Calculate derivatives
	for(i=0; i < NumMemBlocks; ++i)
	{
		lstm.blocks[i].ingate.ComputeFprime();
		lstm.blocks[i].forgate.ComputeFprime();
		
		for(k=0; k < NumCells; ++k)
		{
			///object_post((t_object *)x, "	Cell %ld", k);
			lstm.blocks[i].cells[k].ComputeGprime();  // for input to cell
			lstm.blocks[i].cells[k].ComputeDsinvj(lstm.blocks[i].forgate.GetOutput(), lstm.blocks[i].ingate.GetFprime(), lstm.blocks[i].inputs);
			lstm.blocks[i].cells[k].ComputeDsphivj(lstm.blocks[i].forgate.GetOutput(), lstm.blocks[i].forgate.GetFprime(), lstm.blocks[i].inputs);		
			lstm.blocks[i].cells[k].ComputeDscvj(lstm.blocks[i].forgate.GetOutput(), lstm.blocks[i].ingate.GetOutput(), lstm.blocks[i].inputs);
		}
	}
	
	squareError = 0.0; // reset w/ e/a pass?
	
	for(i=0; i < NumOutputs; ++i)
	{
		if (testing == 0) {
		lstm.outputs[i].err = 0.0; ///?
		lstm.outputs[i].ComputeError(lstm.targets[i]);
		lstm.outputs[i].err = lstm.outputs[i].GetError();
		squareError += lstm.outputs[i].err * lstm.outputs[i].err; ///?
		
		lstm.outputs[i].ComputeFprime();
		lstm.outputs[i].ComputeDelta();  // delta_k	
		}
		if (print) object_post((t_object *)x, "	> Output %ld = %f", i, lstm.outputs[i].GetOutput());
	}
	
	// *** OUTPUT from OutputUnits ***
	t_member *l;
	l = x->b_mem;
    outlet_list(l->m_out, gensym("list"), NumOutputs, sendOut); 
	
	//Backward pass:
	
	// If training, do error & weight updates. If testing, don't.
	if (testing == 0) {
		
	// *** OUTPUT NET SQUARE ERROR ***
	l = x->b_mem+2;
	outlet_float(l->m_out, squareError);
	if (print) object_post((t_object *)x, "	> squareError = %f", squareError);
	}
		
	for(i=0; i < NumMemBlocks; ++i)
	{
		lstm.blocks[i].outgate.ComputeFprime();
		for(k=0; k < NumCells; ++k)
		{
			lstm.blocks[i].cells[k].ComputeDelta(i, lstm.outputs);  // i is blocknum ///?
			lstm.blocks[i].cells[k].ComputeHprime();
		}
		lstm.blocks[i].outgate.ComputeDeltaOutj(lstm.blocks[i].cells);
		
		for(k=0; k < NumCells; ++k)
			lstm.blocks[i].cells[k].ComputeEcvj(lstm.blocks[i].outgate.GetOutput());
	}
		
	if (testing == 0) {
		
	// Weight Updates!
	float a = 0.0;
	float b = 0.0;
	lastchange += change;
	change = 0.0;
		
	for(i=0; i < NumOutputs; ++i) {
		a += lstm.outputs[i].weights[i];
		lstm.outputs[i].UpdateWeights();
		b += lstm.outputs[i].weights[i];
	}	
	
	for(i=0; i < NumMemBlocks; ++i)
	{
		for(k=0;k<NumTotalInputs;++k) {
			a += lstm.blocks[i].outgate.weights[k] + lstm.blocks[i].ingate.weights[k] + lstm.blocks[i].forgate.weights[k];
		}	
		
		lstm.blocks[i].outgate.UpdateWeights(lstm.blocks[0].inputs);
		lstm.blocks[i].ingate.UpdateWeights(lstm.blocks[i].cells);
		lstm.blocks[i].forgate.UpdateWeights(lstm.blocks[i].cells);
		
		for(k=0;k<NumTotalInputs;++k) {
			b += lstm.blocks[i].outgate.weights[k] + lstm.blocks[i].ingate.weights[k] + lstm.blocks[i].forgate.weights[k];
		}
		
		for(k=0; k < NumCells; ++k) {
			a += lstm.blocks[i].cells[k].weights[k];
			lstm.blocks[i].cells[k].UpdateWeights();
			b += lstm.blocks[i].cells[k].weights[k];
		}
	}
		/*
	change = (float)fabs(a - b);
		
		object_post((t_object *)x, "	* Net weight change over past %ld timesteps: %f", minchangethresh, lastchange);
		
		// increment minchangecount as long as constant stream of minimal weight change is maintained
		if (lastchange <= minchange) {
			minchangecount++;
			float percentdone = minchangecount/minchangethresh;
			object_post((t_object *)x, "	* Net weight change threshold: %f", percentdone);
			
			if (minchangecount >= minchangethresh) {
				minchangecount = 0;
				lastchange = 0;
				if (percentdone >= 1.0) {
					object_error((t_object *)x, "Done training! or it's prolly no more use trying...)");
					testing = 1;
				
					// *** OUTPUT 1 ***
					l = x->b_mem+2;
					outlet_int(l->m_out, 1);
				}
			}
		else {
			
			object_post((t_object *)x, "	* Net weight change threshold: 0");
			
			minchangecount = 0;
			lastchange = 0.0;
			
			// *** OUTPUT 1 ***
			l = x->b_mem+2;
			outlet_int(l->m_out, 0);
		}
		}
		*/
		/* 
		float asd = everyhowmany/8000;
		object_post((t_object *)x, "	* ehm: %ld", everyhowmany);
		object_post((t_object *)x, "	* update learning rates: %lf", asd);
		
	// Decrease learning rate (all momentums)?
	
		if (change > minchange) {
		
			everyhowmany++;
			
			if (everyhowmany >= 8000) { // don't update too often 
					
				everyhowmany = 0;
				
					m = 0.995*m;
					object_post((t_object *)x, "	* recurrent unit momentum lowered to %lf", m);
		
					m0 = 0.995*m0;
					object_post((t_object *)x, "	* memory block momentum lowered to %lf", m0);
				
					m0out = 0.995*m0out;
					object_post((t_object *)x, "	* output unit momentum lowered to %lf", m0out);
			}
		}
		*/
	}
	
	// report time this took
	cycleTime = ((clock() - cycleTime)/CLOCKS_PER_SEC) * 1000; // make it milliseconds
	l = x->b_mem+1;
	outlet_int(l->m_out, floor(cycleTime));
	
	if (print) object_post((t_object *)x, "	: cycle time: %ld ms", (int)cycleTime);
	
	if (print) object_post((t_object *)x, "	}");
		
	///}

}

// #############################################################

void lstm_float(t_lstm *x, double f)
{
	t_atom a;
	atom_setfloat(&a, f);
	lstm_atom(x,&a);
	
	/// ***
	
	systhread_mutex_lock(x->c_mutex); // Don't let them change while they're being loaded!
	
	int origin = proxy_getinlet((t_object *)x); // which inlet did the message come from?
	
	switch (origin){
		case 1: // do nothing
		{
			object_error((t_object *)x, "I don't take floats.");
			break;
		}
		case 2: // middle inlet sets target output
		{
			// Network must be in training mode!
			if (testing == 1) 
				object_error((t_object *)x, "Um, targets are only for training; ignoring incoming targets...");
			else {
				
			// Only load targets if the last ones have been used
			if (TargetsLoaded)
				object_error((t_object *)x, "Cannot load new targets: waiting for inputs...");
			// The number of targets must match the number of output units!
			else 
			{
			// The number of targets must match the number of output units!
			if (NumOutputs == 1) {
				// Load targets
				lstm.targets[0] = f;
				Targets[0] = lstm.targets[0];
				
				if (print) object_post((t_object *)x, "T = %ld {", T);
				if (print) object_post((t_object *)x, "	< Target = %f", lstm.targets[0]);
				///lstm.ScaleTargets();
				///object_post((t_object *)x, "	< Scaled Target = %f", lstm.targets[0]);
				
				TargetsLoaded = true;
			}
			else {
				object_error((t_object *)x, "	Number of targets (1) must match number of output units (%ld)!", NumOutputs);
			}
			///}
			} // end if targets loaded
			} // end if training
			break;
		}
		default: // set input
		{
			// Cannot load inputs until targets have updated!
			if (!TargetsLoaded && testing == 0)
				object_error((t_object *)x, "Cannot load new inputs: waiting for targets...");
			else {
				// The number of inputs must match the number of input units!
				if (NumInputs == 1) {
						// Load input units
						
						Inputs[0] = f;
						lstm.inputs[0].SetInput(f);
						if (print) object_post((t_object *)x, "	< Input = %f", lstm.inputs[0].input);
						///lstm.inputs[0].ScaleInputs();
						///object_post((t_object *)x, "	< Scaled Input = %f", lstm.inputs[0].input);
						T++; // Update time w/ new input
						lstm_LSTM(x);
					}
				else {
					object_error((t_object *)x, "Number of inputs (1) must match number of input units (%ld)!", NumInputs);
				}
			}
			break;
		}
	}
	
	systhread_mutex_unlock(x->c_mutex);
}

// #############################################################

void lstm_int(t_lstm *x, long n)
{
	int origin = proxy_getinlet((t_object *)x); // which inlet did the message come from?
	
	switch (origin){
		case 1: // training
		{
			object_error((t_object *)x, "I don't take ints.");
			break;
		}
		case 2:
		{
			object_error((t_object *)x, "I don't take ints.");
			break;
		}
		default:
		{
			if (n == 0) {
				testing = 0;
				object_post((t_object *)x, "Training. Error & weights will be updated. Make sure targets are wired!");
			}
			else {
				testing = 1;
				object_post((t_object *)x, "Testing. No error or weight updates. No need for targets.");
			}
			break;
		}
	}
			
}

void lstm_atom(t_lstm *x, t_atom *a)
{
	t_member *m;
	long in = proxy_getinlet((t_object *)x);
	
	m = x->b_mem + in;
	m->m_on = true;
	m->m_argc = 1;
	m->m_argv[0] = *a;
	if (lstm_all(x)) {
		lstm_off(x);
		lstm_out(x);
	}
}

short lstm_all(t_lstm *x)
{
	short i;
	t_member *m;
	
	for (i=0,m = x->b_mem; i < x->b_num; i++,m++)
		if (!m->m_on)
			return false;
	return true;
}

void lstm_off(t_lstm *x)
{
	short i;
	t_member *m;
	
	for (i=0,m = x->b_mem; i < x->b_num; i++,m++)
		m->m_on = 0;
}

void lstm_out(t_lstm *x)
{
	short i;
	t_member *m;
	
	for (i=x->b_num-1,m = x->b_mem+i; i >= 0; i--,m--)
		outlet_member(m->m_out,m->m_argc,m->m_argv);
}

void outlet_member(void *out, short argc, t_atom *argv)
{
	if (argc == 1) {
		switch (atom_gettype(argv)) {
			case A_LONG:
				outlet_int(out,atom_getlong(argv));
				break;
			case A_FLOAT:
				outlet_float(out,atom_getfloat(argv));
				break;
			case A_SYM:
				outlet_anything(out,atom_getsym(argv),0,0L);
				break;
		}
	} else if (atom_getsym(argv) == ps_list)
		outlet_list(out,ps_list,argc-1,argv+1);
	else
		outlet_anything(out,atom_getsym(argv),argc-1,argv+1);
}

void lstm_assist(t_lstm *x, void *b, long m, long a, char *s)
{
	// Hover over inlet
	if (m == ASSIST_INLET)
		switch (a) {
			case 0:
				sprintf(s,"Input Unit Values (single float or list)");
				break;
			case 1:
				sprintf(s, "Bang resets network");
				break;
			case 2:
				sprintf(s, "Load target output (single float or list)");
				break;
			default:
				break;
		}
	
	// Hover over outlet
	else {
		switch (a) {
			case 0:
				sprintf(s, "Output Unit Values (single float or list)");
				break;
			case 1:
				sprintf(s, "Time for last network cycle");
				break;
			case 2:
				sprintf(s, "Net Square Error (float); out 0 if still training, 1 if finished");
				break;
			default:
				break;
		}
	}
}


void lstm_inletinfo(t_lstm *x, void *b, long a, char *t)
{
	/*
	 *	red if every  input - 1 has been set and you're looking to the one which will trigger
	 */
	long i, count;
	t_member *m, *m2;
	
	for (i = count = 0, m = x->b_mem; i < x->b_num; i++, m++) {
		if (i == a)
			m2 = m;
		if (m->m_on)
			count++;
	}
	
	if (count >= (x->b_num - 1) && ! m2->m_on)
		*t = 0;
	else
		*t = 1;
}

void lstm_free(t_lstm *x)
{
	short i;
	
	for (i=1; i < x->b_num; i++)
		object_free(x->b_mem[i].m_proxy);
	
	sysmem_freeptr(x->b_mem);
}

//==========================================================

void *lstm_new(t_symbol *s, long argc, t_atom *argv)
{
	// 3 inlets & outlets
	long num = 3;
	
	t_lstm *x;
	
	short i;
	t_member *mem;

	x = (t_lstm *)object_alloc(lstm_class);
	///if (num < 2)
	///	num = 2;
	x->b_num = num;
	x->b_id = 0;
	x->b_mem = (t_member *)sysmem_newptr((unsigned short)(num * sizeof(t_member)));
	for (i=num-1,mem = x->b_mem + i; i >= 0; i--,mem--) {
		if (i)
			mem->m_proxy = proxy_new(x,(long)i,&x->b_id);
		mem->m_out = outlet_new(x,0L);
		mem->m_on = 0;
		mem->m_argc = 1;
		atom_setfloat(&mem->m_argv[0], 0);
	}
	
	///dsp_setup((t_pxobject *)x, 3);	// MSP inlets: arg is # of inlets and is REQUIRED! 
	
	object_post((t_object *)x,     "==================================================");
	object_post((t_object *)x, "  Long Short-Term Memory (LSTM) Neural Network  ");
	object_post((t_object *)x, "  MAX object by Wesley Jackson 2011                       ");
	object_post((t_object *)x, "  Network code provided by Judy Franklin (2004), ");
	object_post((t_object *)x, "	based off pseudocode by Felix Gers, Nicol Schraudolph & Jurgen Schmidhuber (2002)  ");
	object_post((t_object *)x, "=------------------------------------------------");
	
	// POST INSTANTIATION INFO
	
	// object instantiation
	if (x) {
		
		systhread_mutex_new(&x->c_mutex, 0);
		
       
		// READ NECESSARY ARGS:
		if (argc < 4 || argc > 11) 
			object_error((t_object *)x, "I need four to nine arguments!");
		else {
			
			// Arg 1: NUM INPUT UNITS <= 500
			if (((argv)->a_type != A_LONG) | atom_getlong(argv) > 500)
				object_error((t_object *)x, "Sorry, but number of input units must be an integer <= 500!");
				else {
					NumInputs = atom_getlong(argv);
					
			
			// Arg 2: NUM OUTPUT UNITS <= 500
			if (((argv+1)->a_type != A_LONG) | atom_getlong(argv+1) > 500) 
				object_error((t_object *)x, "Sorry, but number of output units must be an integer <= 500!");
					else {
						NumOutputs = atom_getlong(argv + 1);
						
			
			// Arg 3: NUM MEMORY BLOCKS <= 70
			if (((argv+2)->a_type != A_LONG) | atom_getlong(argv+2) > 70) 
				object_error((t_object *)x, "Sorry, but number of memory blocks must be an integer <= 70!");
						else {
							NumMemBlocks = atom_getlong(argv + 2);
							
							
			// Arg 4: NUM MEMORY CELLS <= 70
			if (((argv+3)->a_type != A_LONG) | atom_getlong(argv+3) > 70)  
				object_error((t_object *)x, "Sorry, but number of memory cells must be an integer <= 70!");
							
							// If no errors at all...
							else {
								NumCells = atom_getlong(argv + 3);
								
								
								NumTotalInputs = NumMemBlocks*NumCells + NumInputs + 1;
								
								
								// just throw in default optional arguments for now; they may be overriden next
								m = 0.0;
								m0 = 0.0;
								m0out = 0.0;
								Alpha = 0.15;
								alpham = 0.0;
								AlphaOut = 0.05;
								StopError = 0.02;
								
								// Initialize new NW
								lstm_initNW(x);
								
							}}}}}
	
	// READ OPTIONAL ARGS : m, m0, m0out, Alpha, AlphaOut
	
		if (argc > 4 && argc <= 11) {
			
		// Arg 5: M <= 1.0
		if (((argv+4)->a_type != A_FLOAT) | atom_getfloat(argv+4) > 1.0)
			object_error((t_object *)x, "Sorry, but recurrent unit momentum rate must be a float < 1.0!");
		else {
			m = atom_getfloat(argv+4);
			
			
			if (argc > 5)
		// Arg 6: m0 <= 1.0
			if (((argv+5)->a_type != A_FLOAT) | atom_getfloat(argv+5) > 1.0)
				object_error((t_object *)x, "Sorry, but hidden unit (blocks) momentum rate must be a float < 1.0!");
			else {
				m0 = atom_getfloat(argv+5);
				
		
				if (argc > 6)
		// Arg 7: m0out <= 1.0
				if (((argv+6)->a_type != A_FLOAT) | atom_getfloat(argv+6) > 1.0)
					object_error((t_object *)x, "Sorry, but output unit momentum rate must be a float < 1.0!");
				else {
					m0out = atom_getfloat(argv+6);
					
		
					if (argc > 7)
		// Arg 8: Alpha
					if (((argv+7)->a_type != A_FLOAT) | atom_getfloat(argv+7) > 1.0)
						object_error((t_object *)x, "Sorry, but alpha must be a float < 1.0!");
					else {
						Alpha = atom_getfloat(argv+7);
						
		
						if (argc > 8)
							// Arg 9: AlphaOut
							if (((argv+8)->a_type != A_FLOAT) | atom_getfloat(argv+8) > 1.0)
								object_error((t_object *)x, "Sorry, but alpham must be a float < 1.0!");
							else {
								alpham = atom_getfloat(argv+8);
								
						
						if (argc > 9)
		// Arg 9: AlphaOut
						if (((argv+9)->a_type != A_FLOAT) | atom_getfloat(argv+9) > 1.0)
							object_error((t_object *)x, "Sorry, but alpha out must be a float < 1.0!");
						else {
							AlphaOut = atom_getfloat(argv+9);
							
							
							if (argc == 11)
	    // Arg 10: StopError
							if (((argv+10)->a_type != A_FLOAT) | atom_getfloat(argv+10) > 1.0)
								object_error((t_object *)x, "Sorry, but stop error must be a float < 1.0!");
							else {
								StopError = atom_getfloat(argv+10);
								
							}}}}}}}}
	//}

	// Enforce default training
	testing = 0;
	TargetsLoaded = false;
	minchange = 0.0000001;
	minchangethresh = 3500;
		
		
	
	}
	
	return x;
}

