// header file lstm.hpp
// from Judy Franklin, Smith College, 2004

#ifndef ANN_H
#define ANN_H

#include<stdio.h>
#include<iostream.h>
#include<string.h>

long NumInputs = 500; // = 1;
long NumOutputs= 500; // = 1;
long NumMemBlocks = 70; // = 1;
long NumCells = 70; // = 1;
long NumTotalInputs = NumCells*NumMemBlocks + NumInputs + 1;

double biasFactor = -.1;
// if bias is changed, need to fix up InitInputs()
double sigexp = 1.0;           // T in the sigmoid exponential
// output unit learning rate
double InputScalar = 1.0;
int directInputFlag = 1;  // set to 1 for output units to get external inputs

class MemoryCell;
///class MemBlock;
class InputUnit;
class OutputUnit;

//==========================================================

class InputUnit
{	 
	
public:                      
	InputUnit();    
	void SetInput(double);
	void ScaleInputs();
	double GetOutput();
	
	/// was protected
	double thisone;
	double input;
};

//==========================================================

class InputGate
{
protected:
	
	
	
public:                      
	InputGate();         // pass it the input ptr when constructed       
	double GetOutput();
	void ResetGate();
	double GetSum();
	double ComputeSum(double * inputs);
	double ComputeOutput();  // these are called activations in LSTM literature
	
	double ComputeFprime();
	double GetFprime();
	void InitBias(double bias);
	void PrintOutput();             
	void UpdateWeights(MemoryCell *);
	double GetWeight(int);  
	void PrintWeights(FILE * debug);
	void SetWeight(int,double); 
	
	double output;  // function f, range [0,1]
	double err;
	double delta;
	double sum;
	double fprime;
	double weights[6000];  
	double deltaWeights[6000];  // momentum terms
};

//==========================================================

class ForgetGate
{
protected:
	
	
	
public:                      
	ForgetGate();         // pass it the input ptr when constructed        
	double GetOutput();
	
	void ResetGate();
	double GetSum();
	double ComputeSum(double * inputs);
	double ComputeOutput();  // these are called activations in LSTM literature
	double ComputeFprime();
	double GetFprime();
	void InitBias(double bias);
	
	// was private
	void PrintOutput();             
	void UpdateWeights(MemoryCell *s);
	double GetWeight(int);  
	void PrintWeights(FILE * debug);
	void SetWeight(int,double); 
	
	double output;  // function f, range [0,1]
	double err;
	double delta;
	double sum;
	double fprime;
	double weights[6000];  
	double deltaWeights[6000];  // momentum terms
	
};

//==========================================================

class OutputGate
{
protected:
	
	
public:                      
	OutputGate();         // pass it the input ptr when constructed       
	double GetOutput();
	
	void ResetGate();
	double GetSum();
	double ComputeSum(double * inputs);
	double ComputeOutput();  // these are called activations in LSTM literature
	
	double ComputeError(double target);
	double ComputeFprime();
	double GetFprime();
	void SetError();
	double SetCellDeltas();  // get deltas from cells in this block
	double ComputeDelta();
	void ComputeDeltaOutj(MemoryCell * cells);
	void InitBias(double bias);
	
	
	void PrintOutput();             
	void UpdateWeights(double * inputs);
	double GetWeight(int);  
	void PrintWeights(FILE * debug);
	void SetWeight(int,double); 
	double GetDelta();
	
	//was private
	double output;  // function f, range [0,1]
	double err;
	double deltaOutj;
	double sum;
	double fprime;
	double weights[6000];  
	double deltaWeights[6000];  // momentum terms
	
};    

//==========================================================

class MemoryCell  	// the cell input uses activation function g. range of g is [-2,2]
{
protected:
	
	
public:                      
	MemoryCell();         // pass it the input ptr when constructed       
	void SetNum(int mynum);
	void ResetGate();
	void ResetOutput();
	void ComputeSum(double * inputs);
	double GetSum();
	double ComputeG_net();
	double GetG_net();
	void ComputeScvj(int time, double y_in_j, double y_phi);  // input gate and forget gate args
	double GetScvj();
	double ComputeOutput(double y_out_j);  // these are called activations in LSTM literature
	
	double GetOutput();
	
	double ComputeEcvj(double y_outj);
	double GetEcvj();
	double ComputeGprime();
	double GetGprime();
	double ComputeHprime();
	double GetHprime();
	
	double SetCellDeltas();  // get deltas from cells in this block
	double ComputeDelta(int blockNumber, OutputUnit * outputs);
	
	void ComputeDscvj(double y_phij, double y_inj, double * inputs);  // input gate and forget gate args
	double GetDscvj(int);
	void ComputeDsinvj(double y_phij, double fprime_inj, double * inputs);  // input deriv and forget gate args
	double GetDsinvj(int);
	void ComputeDsphivj(double y_phij, double fprime_phij, double * inputs);  // forget deriv and forget gate args
	double GetDsphivj(int);
	void InitDerivs();
	void Init();
	
	
	void PrintOutput();             
	void UpdateWeights();
	double GetWeight(int);  
	void PrintWeights(FILE * debug);
	void SetWeight(int,double); 
	double GetDelta();
	
	//was private
	int mynum;
	double output;  // y_c_v_j(t) - the cell activation, function h, range is [-1,1]
	double suboutput;
	double gsuboutput;
	double ecvj;  // error
	double delta;
	double sum;
	double g_net;
	double scvj;
	double hprime;
	double gprime;
	double weights[6000];  
	double deltaWeights[6000];  // momentum terms
	double dscvj[6000];  // Deriv for cell weight update
	double dsinvj[6000];  // Deriv for input gate weight update
	double dsphivj[6000];  // Deriv for forget gate weight update
	
};

//==========================================================

class MemBlock
{
protected:
	
public:
	OutputGate outgate;
	ForgetGate forgate;
	InputGate ingate;
	MemoryCell cells[70];  // cells have own input and output units
	static	double inputs[6000];
	MemBlock();
	void Init(int i);
	void InitDerivs();
	void SetInputs(int time, MemBlock * blocks, InputUnit * externalInputs);
	
	int mynum; // was protected
};

//==========================================================

class OutputUnit
{
protected:
	
	
public:                      
	OutputUnit();         // pass it the input ptr when constructed       
	void SetInputs(int timestep, MemBlock * blocks, InputUnit * externalInputs);
	double GetSum();
	double ComputeSum();
	double ComputeOutput();
	double GetOutput();
	double ComputeError(double target);
	double GetError();
	double ComputeFprime();
	double GetFprime();
	void PrintOutput();             
	void UpdateWeights();
	double GetWeight(int);  
	void PrintWeights(FILE * debug);
	void PrintInputs(FILE * debug);
	void SetWeight(int,double); 
	double GetDelta();
	double ComputeDelta();  // this one's different because it uses errors
	// in addition to all the other units' deltas
	
	// originally private:
	double weights[6000];  
	double deltaWeights[6000];  // momentum terms
	static double inputs[6000];  // Inputs come from RTRL units
	
	double output;   // uses function f, range [0,1]
	double err; 
	double delta;
	double sum;
	double fprime;
	
};

//==========================================================

class LSTMnet
{
protected:
	
	
public:
	LSTMnet();
	void InitDerivs();
	void ScaleTargets();
	///void GetNextInputs(int, int, double Inputs[500][500]/*[NumExamples][T][NumInputs]*/);
	///void GetNextTargets(int, int, double Targets[500][500]/*[NumExamples][T][NumOutputs]*/, FILE *);
	///void RunSim(double Inputs[500][500]/*[NumExamples][T][NumInputs]*/, double Targets[500][500]/*[NumExamples][T][NumOutputs]*/);
	///void RunSimTest(double Inputs[500][500]/*[NumExamples][T][NumInputs]*/, double Targets[500][500]/*[NumExamples][T][NumOutputs]*/);
	
	//was private
	MemBlock blocks[70];
	InputUnit inputs[500];
	OutputUnit outputs[500];
	double targets[500];
};

#endif          
